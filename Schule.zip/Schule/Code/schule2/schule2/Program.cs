﻿using System;

namespace schule2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hello, please enter your username: ");
            string UserName = Console.ReadLine();
            Console.Clear();
            string name = "mm29942";
            string passwd = "M314159";
            string Name = "moritz.rueben";
            string Passwd = "Mm2020mM";

            if (name == UserName)
            {
                Console.WriteLine("welcome home!");
                Console.Write("Please enter your Password: ");
                string Password = Console.ReadLine();
                if (passwd == Password)
                {
                    Console.Clear();
                    Console.WriteLine("Login was successfully!");
                    Console.ReadLine();
                    Console.Clear();
                    Console.Write("Have a nice day!");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Try again later!");
                    Console.ReadLine();
                    Console.Clear();
                }
            }
            else
            {
                if (Name == UserName)
                {
                    Console.WriteLine("welcome home!");
                    Console.Write("Please enter your Password: ");
                    string Password = Console.ReadLine();
                    if (Passwd == Password)
                    {
                        Console.Clear();
                        Console.WriteLine("Login was successfully!");
                        Console.ReadLine();
                        Console.Clear();
                        Console.Write("Have a nice day!");
                        Console.ReadLine();
                        Console.Clear();
                    }
                }
            }
            if (UserName != Name && UserName != name)
            {
                Console.WriteLine("Try again later!");
                Console.ReadLine();
                Console.Clear();
            }
        }
    }
}
