using System;
using System.Collection.Generic;
using System.Linq;
using System.Text;
using System.Threading.Task;

namespace test
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.Write("Welcome, Please enter username: ");
			string UserName = ConsoleReadLine();
			Console.Clear();
			string name = mm29942;
			if(UserName == name)
			{
				Console.WriteLine("Hello " +UserName);
				Console.ReadLine();
			}
			else(no)
			{
				Console.WriteLine("Thats the wrong user name. Please reboot!)
				Console.ReadKeyLine();				
				Console.Clear();
			}
		}
	
	}
	
}
